# ThreeJS-primitives
3 primitives with some features
http://www.jlabstudio.com/webgl/2013/04/three-js-tutorial-3-texturas-iluminacion-y-transparencias/
http://www.jlabstudio.com/webgl/2011/11/webgl-tutorial-6-eventos-de-teclado-y-filtros-de-textura/
